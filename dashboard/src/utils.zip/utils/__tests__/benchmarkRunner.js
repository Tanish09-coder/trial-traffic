import { VehicleManager } from '../VehicleManager.js';
import { SignalManager } from '../SignalManager.js';
import { SimulationClock } from '../SimulationClock.js';
import { TRAFFIC_CONSTANTS } from '../constants.js';
import fs from 'fs';
import path from 'path';

function createPRNG(seed = 12345) {
  let s = seed >>> 0;
  return function() {
    s = (s + 0x6D2B79F5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function assert(condition, message) {
  if (!condition) {
    console.error(`❌ BENCHMARK ASSERTION FAILED: ${message}`);
    throw new Error(`Benchmark Assertion Failed: ${message}`);
  }
}

/**
 * Generate deterministic arrival schedule for approaches N, E, W using documented seed
 */
function generateSyntheticSchedule(seed, maxDurationSec = 158.6) {
  const prng = createPRNG(seed);
  const schedule = [];
  const directions = ['N', 'E', 'W'];
  let idCounter = 1;

  const getRate = (dir, t) => {
    let baseRate = 0.30;
    switch (dir) {
      case 'N': baseRate = 0.30 + 0.25 * Math.sin((2 * Math.PI * t) / 120); break;
      case 'E': baseRate = 0.25 + 0.30 * Math.sin((2 * Math.PI * t) / 150 + Math.PI / 2); break;
      case 'W': baseRate = 0.28 + 0.28 * Math.sin((2 * Math.PI * t) / 200 + Math.PI); break;
    }
    return Math.max(0.08, parseFloat(baseRate.toFixed(3)));
  };

  directions.forEach(direction => {
    let t = prng() * 2.0;
    while (t < maxDurationSec) {
      const ratePerSec = getRate(direction, t);
      const dtArrival = -Math.log(1 - Math.min(0.99, prng())) / ratePerSec;
      t += Math.max(0.5, dtArrival);

      if (t >= maxDurationSec) break;

      const r = prng();
      const vType = r < 0.50 ? 'car' : r < 0.72 ? 'bike' : r < 0.88 ? 'bus' : 'truck';

      schedule.push({
        eventId: `synth-${direction}-${idCounter++}`,
        videoTimeSec: parseFloat(t.toFixed(3)),
        vehicleType: vType,
        mappedDirection: direction
      });
    }
  });

  return schedule;
}

/**
 * Load Bellevue trial video analysis output for South (S)
 */
function loadBellevueSouthArrivals() {
  const cachePath1 = path.join(process.cwd(), '..', 'backend', 'cache', 'south_incoming_run.json');
  const cachePath2 = path.join(process.cwd(), 'backend', 'cache', 'south_incoming_run.json');
  let cachePath = fs.existsSync(cachePath1) ? cachePath1 : fs.existsSync(cachePath2) ? cachePath2 : null;

  assert(cachePath !== null, 'Analysis cache file south_incoming_run.json not found');
  const cacheData = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
  assert(cacheData.status === 'COMPLETED', `Expected cache status COMPLETED, got ${cacheData.status}`);

  return cacheData.arrivalEvents || [];
}

/**
 * Run a single benchmark session for a given strategy ('fixed' | 'adaptive')
 */
function runSingleSession({ strategy, arrivalTimeline, targetDurationSec = 158.6, dt = 0.1 }) {
  const vm = new VehicleManager();
  vm.reset();

  // Clear all initial vehicles and backlog on all approaches; set sources to recorded_video
  ['N', 'S', 'E', 'W'].forEach(d => {
    vm.setApproachSource(d, 'recorded_video');
    vm.clearApproach(d);
  });

  const sm = new SignalManager();
  sm.reset();
  sm.setStrategy(strategy);
  sm.strategy = strategy;
  sm.stagedStrategy = strategy;
  sm.currentSignal = 'N';

  const clock = new SimulationClock(1.0);

  let eventCursor = 0;
  const processedEventIds = new Set();

  // Tracking metrics per tick
  const timeStepCount = Math.round(targetDurationSec / dt);
  const queueHistoryPerDir = { N: [], E: [], S: [], W: [], total: [] };
  const waitSecAccumulatorPerDir = { N: 0, E: 0, S: 0, W: 0 };

  for (let step = 0; step < timeStepCount; step++) {
    const simTime = parseFloat((step * dt).toFixed(3));

    // Dispatch arrival events up to current simTime
    while (
      eventCursor < arrivalTimeline.length &&
      arrivalTimeline[eventCursor].videoTimeSec <= simTime
    ) {
      const event = arrivalTimeline[eventCursor++];
      if (!processedEventIds.has(event.eventId)) {
        processedEventIds.add(event.eventId);
        vm.injectExternalArrival(event.mappedDirection, event);
      }
    }

    // Measure queues before physics tick
    const stoppedQueues = vm.getStoppedQueues(); // includes visible stopped + backlog
    const queuedPCUs = vm.getQueuedPCUs();
    const oldestWaitTimes = vm.getOldestWaitTimes();
    const isOccupied = vm.isIntersectionOccupied();

    ['N', 'E', 'S', 'W'].forEach(d => {
      const dirStoppedTotal = stoppedQueues[d] || 0;
      queueHistoryPerDir[d].push(dirStoppedTotal);

      // Accumulate wait time seconds for stopped visible vehicles and backlog vehicles
      const stoppedVisibleCount = (vm.cars[d] || []).filter(c => c.isStopped).length;
      const backlogCount = (vm.backlog[d] || []).length;
      waitSecAccumulatorPerDir[d] += (stoppedVisibleCount + backlogCount) * dt;
    });

    const totalStoppedStep = Object.values(stoppedQueues).reduce((a, b) => a + b, 0);
    queueHistoryPerDir.total.push(totalStoppedStep);

    // Update signal controller
    sm.updateSignal(stoppedQueues, stoppedQueues, queuedPCUs, oldestWaitTimes, dt, isOccupied);

    // Update vehicle positions
    vm.updateVehicles(sm.currentSignal, sm.phase, dt);
  }

  // End of session metrics extraction
  const finalState = vm.getState();
  const completedDepartures = vm.getCompletedDepartures();

  // Calculate accumulated wait time from completed departures + remaining wait times
  const totalCompletedWaitSec = completedDepartures.reduce((acc, d) => acc + (d.delay || 0), 0);

  const metricsPerDir = {};
  ['N', 'E', 'S', 'W'].forEach(d => {
    const offeredArrivals = arrivalTimeline.filter(e => e.mappedDirection === d).length;
    const acceptedArrivals = vm.getCompletedArrivals().filter(a => a.direction === d).length;
    const departures = completedDepartures.filter(dep => dep.direction === d).length;
    const visibleCars = (vm.cars[d] || []).length;
    const backlogCars = (vm.backlog[d] || []).length;

    const qHist = queueHistoryPerDir[d];
    const avgStoppedQueue = parseFloat((qHist.reduce((a, b) => a + b, 0) / qHist.length).toFixed(2));
    const maxStoppedQueue = Math.max(...qHist, 0);
    const accumWaitSec = parseFloat(waitSecAccumulatorPerDir[d].toFixed(1));

    metricsPerDir[d] = {
      offeredArrivals,
      acceptedArrivals,
      rejectedArrivals: offeredArrivals - acceptedArrivals,
      departures,
      visibleCarsRemaining: visibleCars,
      backlogCarsRemaining: backlogCars,
      accumulatedWaitSec: accumWaitSec,
      avgStoppedQueue,
      maxStoppedQueue
    };
  });

  const totalOffered = arrivalTimeline.length;
  const totalAccepted = vm.getCompletedArrivals().length;
  const totalDepartures = completedDepartures.length;
  const totalVisible = Object.values(vm.cars).reduce((sum, lane) => sum + lane.length, 0);
  const totalBacklog = Object.values(vm.backlog).reduce((sum, bLane) => sum + bLane.length, 0);

  const totalQHist = queueHistoryPerDir.total;
  const totalAvgStoppedQueue = parseFloat((totalQHist.reduce((a, b) => a + b, 0) / totalQHist.length).toFixed(2));
  const totalMaxStoppedQueue = Math.max(...totalQHist, 0);
  const totalAccumWaitSec = parseFloat(Object.values(waitSecAccumulatorPerDir).reduce((a, b) => a + b, 0).toFixed(1));

  return {
    strategy,
    targetDurationSec,
    totalOfferedArrivals: totalOffered,
    totalAcceptedArrivals: totalAccepted,
    totalRejectedArrivals: totalOffered - totalAccepted,
    totalDepartures,
    totalVisibleCarsRemaining: totalVisible,
    totalBacklogCarsRemaining: totalBacklog,
    totalAccumulatedWaitSec: totalAccumWaitSec,
    timeWeightedAvgStoppedQueue: totalAvgStoppedQueue,
    maxStoppedQueue: totalMaxStoppedQueue,
    perApproach: metricsPerDir,
    processedEventIdsCount: processedEventIds.size
  };
}

export function runPhase3ABenchmark(seed = 42) {
  console.log('===========================================================');
  console.log(`  STARTING PHASE 3A BENCHMARK (Seed: ${seed}, Duration: 158.6s) `);
  console.log('===========================================================\n');

  // 1. Load Bellevue South arrivals & synthetic N, E, W schedules
  const southArrivals = loadBellevueSouthArrivals();
  const synthSchedule = generateSyntheticSchedule(seed, 158.6);

  // Combine into single arrival timeline sorted by videoTimeSec
  const unifiedTimeline = [...southArrivals, ...synthSchedule];
  unifiedTimeline.sort((a, b) => a.videoTimeSec - b.videoTimeSec);

  console.log(`[Input Data] South Bellevue clip arrivals: ${southArrivals.length}`);
  console.log(`[Input Data] Synthetic arrivals (N/E/W, Seed ${seed}): ${synthSchedule.length}`);
  console.log(`[Input Data] Total Unified Input Arrivals: ${unifiedTimeline.length}\n`);

  // 2. Run Fixed Session
  const fixedResults = runSingleSession({
    strategy: 'fixed',
    arrivalTimeline: unifiedTimeline,
    targetDurationSec: 158.6,
    dt: 0.1
  });

  // 3. Run Adaptive Session
  const adaptiveResults = runSingleSession({
    strategy: 'adaptive',
    arrivalTimeline: unifiedTimeline,
    targetDurationSec: 158.6,
    dt: 0.1
  });

  // 4. Fairness & Repeatability Assertions
  console.log('--- FAIRNESS & REPEATABILITY ASSERTION CHECKS ---');

  // Assertion 1: Both sessions received identical input arrivals
  assert(
    fixedResults.totalOfferedArrivals === adaptiveResults.totalOfferedArrivals,
    `Offered arrivals mismatch: Fixed=${fixedResults.totalOfferedArrivals}, Adaptive=${adaptiveResults.totalOfferedArrivals}`
  );
  assert(
    fixedResults.totalOfferedArrivals === unifiedTimeline.length,
    `Offered arrivals must equal input timeline count (${unifiedTimeline.length})`
  );

  // Assertion 2: Each event delivered exactly once
  assert(
    fixedResults.processedEventIdsCount === unifiedTimeline.length,
    `Fixed session processed event count (${fixedResults.processedEventIdsCount}) must equal input timeline count`
  );
  assert(
    adaptiveResults.processedEventIdsCount === unifiedTimeline.length,
    `Adaptive session processed event count (${adaptiveResults.processedEventIdsCount}) must equal input timeline count`
  );

  // Assertion 3: Accounting Invariant holds for both sessions
  // Accepted Arrivals = Departures + Visible Cars Remaining + Backlog Cars Remaining
  const fixedAccounted = fixedResults.totalDepartures + fixedResults.totalVisibleCarsRemaining + fixedResults.totalBacklogCarsRemaining;
  assert(
    fixedResults.totalAcceptedArrivals === fixedAccounted,
    `Fixed accounting invariant failed: Accepted (${fixedResults.totalAcceptedArrivals}) != Departures (${fixedResults.totalDepartures}) + Visible (${fixedResults.totalVisibleCarsRemaining}) + Backlog (${fixedResults.totalBacklogCarsRemaining})`
  );

  const adaptiveAccounted = adaptiveResults.totalDepartures + adaptiveResults.totalVisibleCarsRemaining + adaptiveResults.totalBacklogCarsRemaining;
  assert(
    adaptiveResults.totalAcceptedArrivals === adaptiveAccounted,
    `Adaptive accounting invariant failed: Accepted (${adaptiveResults.totalAcceptedArrivals}) != Departures (${adaptiveResults.totalDepartures}) + Visible (${adaptiveResults.totalVisibleCarsRemaining}) + Backlog (${adaptiveResults.totalBacklogCarsRemaining})`
  );

  // Assertion 4: Repeatability check - re-running Fixed with seed 42 produces identical outputs
  const repeatFixed = runSingleSession({
    strategy: 'fixed',
    arrivalTimeline: unifiedTimeline,
    targetDurationSec: 158.6,
    dt: 0.1
  });
  assert(
    repeatFixed.totalDepartures === fixedResults.totalDepartures &&
    repeatFixed.totalAccumulatedWaitSec === fixedResults.totalAccumulatedWaitSec,
    'Repeatability check failed: Re-running Fixed produced different results'
  );

  console.log('✅ ALL 5 BENCHMARK FAIRNESS & REPEATABILITY ASSERTIONS PASSED!\n');

  // Compute Percentage Differences (Fixed as denominator)
  const calcPctDiff = (fixedVal, adaptiveVal) => {
    if (fixedVal === 0) return 'N/A';
    const pct = ((adaptiveVal - fixedVal) / fixedVal) * 100;
    return `${pct >= 0 ? '+' : ''}${pct.toFixed(1)}%`;
  };

  const comparisonTable = {
    totalOfferedArrivals: { fixed: fixedResults.totalOfferedArrivals, adaptive: adaptiveResults.totalOfferedArrivals, diffPct: calcPctDiff(fixedResults.totalOfferedArrivals, adaptiveResults.totalOfferedArrivals) },
    totalAcceptedArrivals: { fixed: fixedResults.totalAcceptedArrivals, adaptive: adaptiveResults.totalAcceptedArrivals, diffPct: calcPctDiff(fixedResults.totalAcceptedArrivals, adaptiveResults.totalAcceptedArrivals) },
    totalRejectedArrivals: { fixed: fixedResults.totalRejectedArrivals, adaptive: adaptiveResults.totalRejectedArrivals, diffPct: calcPctDiff(fixedResults.totalRejectedArrivals, adaptiveResults.totalRejectedArrivals) },
    totalDepartures: { fixed: fixedResults.totalDepartures, adaptive: adaptiveResults.totalDepartures, diffPct: calcPctDiff(fixedResults.totalDepartures, adaptiveResults.totalDepartures) },
    totalVisibleCarsRemaining: { fixed: fixedResults.totalVisibleCarsRemaining, adaptive: adaptiveResults.totalVisibleCarsRemaining, diffPct: calcPctDiff(fixedResults.totalVisibleCarsRemaining, adaptiveResults.totalVisibleCarsRemaining) },
    totalBacklogCarsRemaining: { fixed: fixedResults.totalBacklogCarsRemaining, adaptive: adaptiveResults.totalBacklogCarsRemaining, diffPct: calcPctDiff(fixedResults.totalBacklogCarsRemaining, adaptiveResults.totalBacklogCarsRemaining) },
    totalAccumulatedWaitSec: { fixed: fixedResults.totalAccumulatedWaitSec, adaptive: adaptiveResults.totalAccumulatedWaitSec, diffPct: calcPctDiff(fixedResults.totalAccumulatedWaitSec, adaptiveResults.totalAccumulatedWaitSec) },
    timeWeightedAvgStoppedQueue: { fixed: fixedResults.timeWeightedAvgStoppedQueue, adaptive: adaptiveResults.timeWeightedAvgStoppedQueue, diffPct: calcPctDiff(fixedResults.timeWeightedAvgStoppedQueue, adaptiveResults.timeWeightedAvgStoppedQueue) },
    maxStoppedQueue: { fixed: fixedResults.maxStoppedQueue, adaptive: adaptiveResults.maxStoppedQueue, diffPct: calcPctDiff(fixedResults.maxStoppedQueue, adaptiveResults.maxStoppedQueue) }
  };

  const benchmarkResultPayload = {
    metadata: {
      title: 'Phase 3A Fixed vs Adaptive Benchmark Result',
      timestamp: new Date().toISOString(),
      randomSeed: seed,
      durationSec: 158.6,
      timestepSec: 0.1,
      videoSource: 'backend/videos/bellevue_trial.mp4 (South approach)',
      controllerSettings: {
        fixedDurations: TRAFFIC_CONSTANTS.SIGNAL_POLICY.FIXED_DURATIONS,
        yellowDurationSec: TRAFFIC_CONSTANTS.SIGNAL_POLICY.YELLOW_DURATION_SEC,
        allRedDurationSec: TRAFFIC_CONSTANTS.SIGNAL_POLICY.ALL_RED_DURATION_SEC,
        adaptiveLimits: {
          minGreen: TRAFFIC_CONSTANTS.SIGNAL_POLICY.MIN_GREEN,
          maxGreen: TRAFFIC_CONSTANTS.SIGNAL_POLICY.MAX_GREEN,
          maxContinuousGreen: TRAFFIC_CONSTANTS.SIGNAL_POLICY.MAX_CONTINUOUS_GREEN
        }
      },
      metricDefinitions: {
        offeredArrivals: 'Total input arrival events provided in schedule',
        acceptedArrivals: 'Count of vehicles injected into visible road or backlog',
        completedDepartures: 'Count of vehicles crossing intersection exit (pos >= 100)',
        totalAccumulatedWaitSec: 'Time-integrated sum of stopped vehicle seconds (visible + backlog + departed)',
        timeWeightedAvgStoppedQueue: 'Time-weighted mean stopped vehicles (visible stopped + backlog)',
        maxStoppedQueue: 'Maximum instantaneous stopped vehicles (visible stopped + backlog)'
      }
    },
    fixedResults,
    adaptiveResults,
    comparisonTable
  };

  // Save machine-readable JSON result
  const outPathBackend = path.join(process.cwd(), '..', 'backend', 'cache', 'phase3a_benchmark_result.json');
  const outPathDashboard = path.join(process.cwd(), 'src', 'utils', '__tests__', 'phase3a_benchmark_result.json');

  try {
    fs.writeFileSync(outPathDashboard, JSON.stringify(benchmarkResultPayload, null, 2));
    if (fs.existsSync(path.dirname(outPathBackend))) {
      fs.writeFileSync(outPathBackend, JSON.stringify(benchmarkResultPayload, null, 2));
    }
  } catch (e) {
    console.warn('Could not write output cache file:', e.message);
  }

  return benchmarkResultPayload;
}

// Auto-run if executed directly via Node
if (process.argv[1] && import.meta.url === `file:///${process.argv[1].replace(/\\/g, '/')}`) {
  try {
    const res = runPhase3ABenchmark(42);
    console.log('SUMMARY METRICS (Fixed vs Adaptive):');
    console.log(JSON.stringify(res.comparisonTable, null, 2));
  } catch (err) {
    console.error('BENCHMARK RUNNER FAILED:', err);
    process.exit(1);
  }
}
